// Run JS only when page content is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.getElementById('menu-toggle');
  const navLinks = document.getElementById('nav-links');
  const themeToggle = document.getElementById('theme-toggle');
  const body = document.body;

  // Menu toggle for mobile
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('show');
    });
  }

  // Theme toggle
  if (themeToggle && body) {
    themeToggle.addEventListener('click', () => {
      const isDark = body.getAttribute('data-theme') === 'dark';
      body.setAttribute('data-theme', isDark ? 'light' : 'dark');
      themeToggle.textContent = isDark ? '🌙 Dark' : '☀️ Light';
    });
  }

  // Typing animation
  const typingText = document.querySelector('.typing-text');
  const message = "Welcome to my portfolio website";
  let index = 0;

  function typeWriter() {
    if (index < message.length) {
      typingText.textContent += message.charAt(index);
      index++;
      setTimeout(typeWriter, 100);
    }
  }
  typeWriter();

  // Sidebar card logic
  const sidebarLinks = document.querySelectorAll('.custom-sidebar a');
  const cards = document.querySelectorAll('.card-section');

  sidebarLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href').substring(1); // Remove #
      
      cards.forEach(card => card.classList.remove('active'));
      const targetCard = document.getElementById(targetId);
      if (targetCard) targetCard.classList.add('active');
    });
  });
});
